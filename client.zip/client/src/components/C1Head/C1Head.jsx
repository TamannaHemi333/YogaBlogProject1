


import './C1Head.css'; // Import the CSS file

const C1Head = () => {
  return (
    <div className="c1head-container">Courses</div>
  )
}

export default C1Head;
