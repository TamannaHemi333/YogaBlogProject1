import React, { Fragment } from 'react';
import './B1.css';

const B1 = () => {
  return (
    <Fragment>
      <div className="blog-container">
        <div className="blog-header">Blog</div>
      </div>
    </Fragment>
  );
}

export default B1;
