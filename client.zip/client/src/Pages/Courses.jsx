import { Fragment } from "react"
import Header from "../components/Header/Header"
import C1Head from "../components/C1Head/C1Head"
import C1AC from "../components/C1AC/C1AC"


const Courses = () => {
  return (
    <Fragment>
      <Header/>
      <C1Head/>
      <C1AC/>
    </Fragment>
   
  )
}

export default Courses